//
//  ViewController.swift
//  Slider
//
//  Created by Monica Qiu on 2018/11/23.
//  Copyright © 2018年 Monica Qiu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var value: UILabel!
    
    
    @IBAction func slider(_ sender: UISlider) {
        //number is the int value from the rounded float
        let number = lroundf(sender.value)
        value.text = "\(number)"
        
    }
    
    
    //+segmented control
    
    @IBAction func segment(_ sender: UISegmentedControl) {
        //similar to arrays: each button has an index
        //0 ... n-1
        //0: private, 1: public
        if sender.selectedSegmentIndex == 0 {
            value.text = "Private"
        } else {
            value.text = "Public"
        }
    }
    
}

