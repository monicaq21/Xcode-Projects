//
//  BreakfastTableViewCell.swift
//  Calendar
//
//  Created by Monica Qiu on 2019-01-06.
//  Copyright © 2019 Monica Qiu. All rights reserved.
//

import UIKit

class BreakfastTableViewCell: UITableViewCell {

    @IBOutlet weak var dishName: UILabel!
    @IBOutlet weak var getButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
