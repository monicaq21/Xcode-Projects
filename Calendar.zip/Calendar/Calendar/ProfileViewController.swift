//
//  ProfileViewController.swift
//  Calendar
//
//  Created by Monica Qiu on 2019-01-05.
//  Copyright © 2019 Monica Qiu. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var Username: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func Save(_ sender: UIButton) {
        self.Username.resignFirstResponder()
        self.Password.resignFirstResponder()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    
}
