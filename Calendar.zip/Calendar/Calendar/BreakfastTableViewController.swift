import UIKit

class BreakfastTableViewController: UITableViewController {

    var myIndex = 0
    let breakfast = ["Boiled eggs","Sandwich","Oatmeal"]
    let breakfastDetail = ["Ingredients: \n 1. 1 egg \n \n Approx. $1.00", //boiled egg
        "Ingredients: \n 1. 2 loafs of bread \n 2. 1 canned tuna.etc \n \n Approx. $6",
        "Ingredients: \n 1. A box of Oatmeal \n \n Approx. $4"
    ]

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return breakfast.count
    }
    //content
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        let dishName = breakfast[indexPath.row]
        cell.textLabel?.text = dishName
        return cell
    }
    
    //title
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Breakfast"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "breakfast")
        
    }

    
    
    
}
