//
//  SecondViewController.swift
//  Calendar
//
//  Created by Monica Qiu on 2018/12/21.
//  Copyright © 2018年 Monica Qiu. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBAction func breakfast(_ sender: UIButton) {
    }
    @IBAction func lunch(_ sender: UIButton) {
    }
    @IBAction func dinner(_ sender: UIButton) {
    }
    @IBOutlet weak var nametitle: UILabel!
    
    var namelabel = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nametitle.text = namelabel
        // Do any additional setup after loading the view, typically from a nib.
    }


}

