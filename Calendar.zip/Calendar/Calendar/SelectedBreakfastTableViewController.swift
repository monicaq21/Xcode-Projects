//
//  SelectedBreakfastTableViewController.swift
//  Calendar
//
//  Created by Monica Qiu on 2019-01-05.
//  Copyright © 2019 Monica Qiu. All rights reserved.
//

import UIKit

class SelectedBreakfastTableViewController: UITableViewController {

    var numberofdishes = 0
    
    var selbreakfast:[String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        selbreakfast.append("")
        
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selbreakfast.count
    }
    
    //title
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Breakfast"
    }
    
    //content
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        let dishName = selbreakfast[indexPath.row]
        cell.textLabel?.text = dishName
        return cell
    }
}
