import UIKit

class ViewController: UIViewController {
    
    //first responder: (for input boxes: show keyboard)
        //is one of editing
    
    
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBAction func logIn(_ sender: UIButton) {
        //when pressed on button, stop first responder
        self.username.resignFirstResponder()
        self.password.resignFirstResponder()
    }
    
    //when pressed on view (button not included because it is on top):
    //stop editing(end everything happening): including first responder
    //built in function: when touched screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}

