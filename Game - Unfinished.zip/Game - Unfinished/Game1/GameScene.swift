//
//  GameScene.swift
//  Game1
//
//  Created by Monica Qiu on 2018/10/20.
//  Copyright © 2018年 Monica Qiu. All rights reserved.
//

import SpriteKit
import GameplayKit

                            //two objects make contact
class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var gameScore = 0
    let scoreLabel = SKLabelNode(fontNamed: "The Bold Font")
    
    
    //to make it "static"
    let player = SKSpriteNode(imageNamed: "playerShip")
    
    //structure
    struct PhysicsCategories{
                        //unsigned integer 32 bits
        static let None : UInt32 = 0
        static let Player : UInt32 = 0b1 //1
        static let Bullet : UInt32 = 0b10 //2
        //3 is player + bullet
        static let Enemy : UInt32 = 0b100 //4
        
    }
    
    
    //An important function to remember for future projects
    //generate a random number between the range
    //in this case, the coordinate of enemy spawn
    func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    func random(min:CGFloat, max:CGFloat) -> CGFloat {
        //generate random number between max and min
        return random() * (max-min) + min
    }
    
    
    //bound of screen
    let gameArea: CGRect
    //initializer
    override init(size: CGSize){
        let maxAspectRatio: CGFloat = 16.0/9.0
        let playableWidth = size.height/maxAspectRatio
        let margin = (size.width-playableWidth) / 2 //2 sides
        gameArea = CGRect(x:margin, y:0, width:playableWidth, height:size.height)
        super.init(size: size)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    //is there as soon as opened (not then appear)
    override func didMove(to view: SKView) {
        
        self.physicsWorld.contactDelegate = self
        
        //spriteNode is an image
        let background = SKSpriteNode(imageNamed: "background")
        //self is like "this" in java (represent SKScene)
        background.size = self.size
        //centre point position
        background.position = CGPoint(x:self.size.width/2,y:size.height/2)
        //layering
        background.zPosition = 0 //backest
        //make background: create object from all descriptions above
        self.addChild(background)
        
        
        //size: scale of 1 is normal size (of img). e.g. 0.5 is half the size
        player.setScale(1)
        //middle, 20% up
        player.position = CGPoint(x:self.size.width/2,y:size.height/5)
        player.zPosition = 2 //so that the bullet is under
        //make the player a "physics body"
        player.physicsBody = SKPhysicsBody(rectangleOf: player.size)
        //not affected by gravity
        player.physicsBody!.affectedByGravity = false
        //assign physics body of player into the player category
        player.physicsBody!.categoryBitMask = PhysicsCategories.Player
        //cannot collide - only go in contact
        player.physicsBody!.collisionBitMask = PhysicsCategories.None
        //the player can make contact with anything in the enemy category
        player.physicsBody!.contactTestBitMask = PhysicsCategories.Enemy
        self.addChild(player)
        
        scoreLabel.text = "Score: 0"
        scoreLabel.fontSize = 70
        scoreLabel.fontColor = SKColor.white
        //when digits are added, the label extends to the right
        scoreLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        //top left corner
        scoreLabel.position = CGPoint(x:self.size.width*0.15, y:self.size.height*0.9)
        scoreLabel.zPosition = 100
        self.addChild(scoreLabel)
        
        
        startNewLevel()
    }
    
    
    func addScore(){
        
        gameScore += 1
        scoreLabel.text = "Score: \(gameScore)"
        
    }
    
    
    
    //run when enemy hits player or player hits bullet
                    //contact is the 2 bodies in contact: body a and b
    func didBegin(_ contact: SKPhysicsContact) {
        //organize the bodies based on their binary number
        //so that we'll know which is which
        var body1 = SKPhysicsBody()
        var body2 = SKPhysicsBody()
        
        //player and enemy or bullet and enemy
        //player is always body1
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            body1 = contact.bodyA
            body2 = contact.bodyB
        } else {
            body2 = contact.bodyA
            body1 = contact.bodyB
        }
        //player hit enemy
        if body1.categoryBitMask == PhysicsCategories.Player && body2.categoryBitMask == PhysicsCategories.Enemy {
            
            //explosion at player and enemy
            if body1.node != nil {
                spawnExplosion(spawnPosition: body1.node!.position)
            }
            if body2.node != nil {
                spawnExplosion(spawnPosition: body2.node!.position)
            }
            
            //remove the node associated with body1
            //(? for optional (if doesn't exist)) e.g. if 2 bullets hit enemy at the same time, prevent gliche
            
            body1.node?.removeFromParent()
            body2.node?.removeFromParent()
        }
        //bullet might hit enemies not on the screen yet
        if body1.categoryBitMask == PhysicsCategories.Bullet && body2.categoryBitMask == PhysicsCategories.Enemy && (body2.node?.position.y)! < self.size.height {
            //explosion only at enemy not bullet
            
            addScore()
            
            if body2.node != nil {
                spawnExplosion(spawnPosition: body2.node!.position)
            }
            
            body1.node?.removeFromParent()
            body2.node?.removeFromParent()
            
            
        }
    }
    
    
    func spawnExplosion(spawnPosition: CGPoint){
        let explosion = SKSpriteNode(imageNamed: "explosion")
        explosion.position = spawnPosition
        explosion.zPosition = 3
        explosion.setScale(0) //start small
        self.addChild(explosion)
        
        let scaleIn = SKAction.scale(to: 1, duration: 0.1)
        let fadeOut = SKAction.fadeOut(withDuration: 0.1)
        let delete = SKAction.removeFromParent()
        let explosionSequence = SKAction.sequence([scaleIn,fadeOut,delete])
        explosion.run(explosionSequence)
    }
    
    
    
    func fireBullet(){
        let bullet = SKSpriteNode(imageNamed: "bullet")
        bullet.setScale(1)
        //match position of the player ship
        bullet.position = player.position
        bullet.zPosition = 1
        bullet.physicsBody = SKPhysicsBody(rectangleOf: bullet.size)
        bullet.physicsBody!.affectedByGravity = false
        bullet.physicsBody!.categoryBitMask = PhysicsCategories.Bullet
        bullet.physicsBody!.collisionBitMask = PhysicsCategories.None
        bullet.physicsBody!.contactTestBitMask = PhysicsCategories.Enemy
        self.addChild(bullet)
        
        //separate actions
        let moveBullet = SKAction.moveTo(y: self.size.height+bullet.size.height, duration: 1) //moveToY -- in the direction of Y. duration: 1 second
        let deleteBullet = SKAction.removeFromParent()
        //use sequence: a list of actions in order
        let bulletSequence = SKAction.sequence([moveBullet,deleteBullet])
        //run the sequence
        bullet.run(bulletSequence)
    }
    
    func spawnEnemy(){
        let randomXStart = random(min: gameArea.minX, max: gameArea.maxX)
        let randomXEnd = random(min: gameArea.minX, max: gameArea.maxX)
                                                    //20% top of screen
        let startPoint = CGPoint (x: randomXStart, y:self.size.height * 1.2)
        let endPoint = CGPoint(x: randomXEnd, y:-self.size.height * 0.2)
        
        let enemy = SKSpriteNode(imageNamed: "enemyShip")
        enemy.setScale(1) //not needed, just in case of modification
        enemy.position = startPoint
        enemy.zPosition = 2
        enemy.physicsBody = SKPhysicsBody(rectangleOf: enemy.size)
        enemy.physicsBody!.affectedByGravity = false
        enemy.physicsBody!.categoryBitMask = PhysicsCategories.Enemy
        //we don't want the enemy's body to collide with anything
        enemy.physicsBody!.collisionBitMask = PhysicsCategories.None
        //notify when enemy hits a player or bullet
        enemy.physicsBody!.contactTestBitMask = PhysicsCategories.Player | PhysicsCategories.Bullet
        self.addChild(enemy)
        
        let moveEnemy = SKAction.move(to: endPoint, duration: 1.5)
        let deleteEnemy = SKAction.removeFromParent()
        let sequenceEnemy = SKAction.sequence([moveEnemy,deleteEnemy])
        enemy.run(sequenceEnemy)
        
        //rotate enemy to the direction it is facing
        //find difference in starting and ending positions
        let diffx = endPoint.x - startPoint.x
        let diffy = endPoint.y - startPoint.y
        let amountToRotate = atan2(diffy, diffx)
        enemy.zRotation = amountToRotate
    }
    
    func startNewLevel() {
        let spawn = SKAction.run(spawnEnemy)
        let waitToSpawn = SKAction.wait(forDuration: 1)
        let spawnSequence = SKAction.sequence([spawn, waitToSpawn])
        let spawnForever = SKAction.repeatForever(spawnSequence)
        let pauseAtStart = SKAction.wait(forDuration: 3)
        let spawnSequence2 = SKAction.sequence([pauseAtStart, spawnForever])
        self.run(spawnSequence2)
    }
    
    
    //touchesBegan: start when the screen is touched
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //fire a bullet when you touch the screen
        fireBullet()
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //when our fingers have moved
            //touch is the variable where touched
        for touch: AnyObject in touches {
            let pointOfTouch = touch.location(in: self) //location of touch in self
            let previousPointOfTouch = touch.previousLocation(in: self)
            let amountDragged = pointOfTouch.x-previousPointOfTouch.x; //x for across screen (move left and right)
            player.position.x += amountDragged
            
            //if player gets out of screen, drag them back in.
            if player.position.x > gameArea.maxX - player.size.width/2 {
                player.position.x = gameArea.maxX - player.size.width/2
            }
            if player.position.x < gameArea.minX + player.size.width/2 {
                player.position.x = gameArea.minX + player.size.width/2
            }
        }
    }
    
    
}
